export const environment = {
    firebase: {
        apiKey: "AIzaSyCO_qJlaraxS-jh80pZWTEeueVl2eK0aDE",
        authDomain: "sedena-e5.firebaseapp.com",
        projectId: "sedena-e5",
        storageBucket: "sedena-e5.appspot.com",
        messagingSenderId: "919180900546",
        appId: "1:919180900546:web:44623af82b938fcd4fa35b"
    },
    production: true
  };


  
