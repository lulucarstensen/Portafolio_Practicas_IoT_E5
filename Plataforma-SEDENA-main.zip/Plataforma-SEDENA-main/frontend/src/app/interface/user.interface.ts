export interface user {
    ID: number,
    Nombre: string,
    Apellido: string,
    Fecha_Nacimiento: string,
    Activo: boolean,
    ID_tarjeta: string,
    Fecha_Ingreso: string
}

